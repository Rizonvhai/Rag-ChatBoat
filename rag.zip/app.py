
import os
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.document_loaders import PyPDFLoader
from langchain_text_splitter import RecursiveCharacterTextSplitter
from langchain_chroma import Chroma
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain
from langchain_core.prompts import ChatPromptTemplate

# --- 1. SETUP ---
# Replace with your actual key
os.environ["OPENAI_API_KEY"] = "ssk-proj-K-3w1ANoKCQxZB8SaV56WkW9sZdbUBD81RYFvBF3NhHMeduwcgGkGN43zFiVFR2v2NziAZ3gVIT3BlbkFJqDmqQ1XTi_z3XPpfrXTCFOOI9b3_C4I_RwEZ2qA6F-0OyaF_EczavmYMFd2Espw_nEcqnrrW4A" 

# --- 2. LOAD & CHUNK ---
print("Reading your PDF...")
loader = PyPDFLoader("Shariful_Resume.pdf")
docs = loader.load()

text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=100)
splits = text_splitter.split_documents(docs)

# --- 3. CREATE VECTOR DB ---
print("Creating memory (Vector DB)...")
vectorstore = Chroma.from_documents(
    documents=splits, 
    embedding=OpenAIEmbeddings(),
    persist_directory="./my_db"
)
retriever = vectorstore.as_retriever()

# --- 4. BUILD THE CHAT BRAIN ---
llm = ChatOpenAI(model="gpt-4o", temperature=0)

system_prompt = (
    "You are a helpful assistant. Use the following context to answer. "
    "If you don't know, say you don't know."
    "\n\n"
    "{context}"
)
prompt = ChatPromptTemplate.from_messages([
    ("system", system_prompt),
    ("human", "{input}"),
])

question_answer_chain = create_stuff_documents_chain(llm, prompt)
rag_chain = create_retrieval_chain(retriever, question_answer_chain)

# --- 5. TEST IT ---
print("\n--- Chatbot Ready! ---")
query = "What is the summary of this resume?"
response = rag_chain.invoke({"input": query})

print(f"User: {query}")
print(f"AI: {response['answer']}")